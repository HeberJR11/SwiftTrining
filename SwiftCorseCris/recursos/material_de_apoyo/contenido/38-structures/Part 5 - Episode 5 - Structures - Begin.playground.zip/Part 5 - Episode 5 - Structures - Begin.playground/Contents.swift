//: ## Episode 05: Structures

// ----------------------------------
//typealias Student = (name: String, grade: Int, pet: String?)
// ----------------------------------



