//
//  happy_challengeTests.swift
//  happy-challengeTests
//
//  Created by Cristian Cardoso on 4/7/22.
//

import XCTest
@testable import happy_challenge

class happy_challengeTests: XCTestCase {
    
    let challenge = Challenge()

    func testA() throws {
    
        let result = challenge.printCode(n: 5, line: "10 8 6 4 2")
        
        print("TEST A:\n\(result)")

        let expected = "***                 \n* *                 \n* * ***             \n* * * *             \n* * * * ***         \n* * * * * *         \n* * * * * * ***     \n* * * * * * * *     \n* * * * * * * * *** \n* * * * * * * * * * \n"
        XCTAssertEqual(result, expected)
    }
    
    func testB() throws {
    
        let result = challenge.printCode(n: 6, line: "1 5 6 5 0 4")
        
        print("TEST B:\n\(result)")

        let expected = "        ***             \n    *** * * ***         \n    * * * * * *     *** \n    * * * * * *     * * \n    * * * * * *     * * \n*** * * * * * *     * * \n"
        XCTAssertEqual(result, expected)
    }
    
    func testC() throws {
    
        let result = challenge.printCode(n: 8, line: "1 2 3 4 5 6 7 8")
        
        print("TEST C:\n\(result)")

        let expected = "                            *** \n                        *** * * \n                    *** * * * * \n                *** * * * * * * \n            *** * * * * * * * * \n        *** * * * * * * * * * * \n    *** * * * * * * * * * * * * \n*** * * * * * * * * * * * * * * \n"
        XCTAssertEqual(result, expected)
    }
    
    func testD() throws {
    
        let result = challenge.printCode(n: 1, line: "5")
        
        print("TEST D:\n\(result)")

        let expected = "*** \n* * \n* * \n* * \n* * \n"
        XCTAssertEqual(result, expected)
    }
    
    func testE() throws {
    
        let result = challenge.printCode(n: 10, line: "10 8 10 6 9 1 2 3 10 10")
        
        print("TEST E:\n\(result)")
        
        let expected = "***     ***                     *** *** \n* *     * *     ***             * * * * \n* * *** * *     * *             * * * * \n* * * * * *     * *             * * * * \n* * * * * * *** * *             * * * * \n* * * * * * * * * *             * * * * \n* * * * * * * * * *             * * * * \n* * * * * * * * * *         *** * * * * \n* * * * * * * * * *     *** * * * * * * \n* * * * * * * * * * *** * * * * * * * * \n"
        XCTAssertEqual(result, expected)
    }
}
