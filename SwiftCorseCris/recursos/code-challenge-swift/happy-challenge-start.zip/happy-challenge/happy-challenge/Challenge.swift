//
//  Challenge.swift
//  happy-challenge
//
//  Created by Cristian Cardoso on 4/7/22.
//

import Foundation

struct Challenge {
    
    //Example A
    
    //Input:
    // n: 5
    // line: "10 8 6 4 2"
    //Output:
    /*
     
     ***
     * *
     * * ***
     * * * *
     * * * * ***
     * * * * * *
     * * * * * * ***
     * * * * * * * *
     * * * * * * * * ***
     * * * * * * * * * *
     
     */
    
    //Example B
    
    //Input:
    // n: 6
    // line: "1 5 6 5 0 4"
    //Output:
    /*
    
             ***
         *** * * ***
         * * * * * *     ***
         * * * * * *     * *
         * * * * * *     * *
     *** * * * * * *     * *
     
     */
    
    //ONCE you finish RUN happy_challengeTest
    
    //TODO:
    func printCode(n: Int, line: String) -> String {
        
        //Reversed mode
        
        let _ = line.split(separator: " ").map { Int($0)!}
        
        return ""
    }
}
