//
//  happy_challengeApp.swift
//  happy-challenge
//
//  Created by Cristian Cardoso on 4/7/22.
//

import SwiftUI

@main
struct happy_challengeApp: App {
    var body: some Scene {
        WindowGroup {
            
        }
    }
}
