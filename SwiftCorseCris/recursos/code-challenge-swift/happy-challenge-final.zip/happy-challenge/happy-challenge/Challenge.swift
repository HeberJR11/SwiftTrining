//
//  Challenge.swift
//  happy-challenge
//
//  Created by Cristian Cardoso on 4/7/22.
//

import Foundation

struct Challenge {
    
    //Example A
    
    //Input:
    // n: 5
    // line: "10 8 6 4 2"
    //Output:
    /*
     
     ***
     * *
     * * ***
     * * * *
     * * * * ***
     * * * * * *
     * * * * * * ***
     * * * * * * * *
     * * * * * * * * ***
     * * * * * * * * * *
     
     */
    
    //Example B
    
    //Input:
    // n: 6
    // line: "1 5 6 5 0 4"
    //Output:
    /*
    
             ***
         *** * * ***
         * * * * * *     ***
         * * * * * *     * *
         * * * * * *     * *
     *** * * * * * *     * *
     
     */
    
    //ONCE you finish RUN happy_challengeTest
    
    //TODO:
    func printCode(n: Int, line: String) -> String {
        
        //Reversed mode
        
        var lineOutput = ""
        let arr = line.split(separator: " ").map { Int($0)!}

        let max = arr.max()!
        for lineCount in stride(from: max, to: 0, by: -1){
            for col in 0...n-1 { // 1
                if arr[col] == lineCount { // == 6
                    lineOutput += "*** "
                }
                if arr[col] > lineCount {
                    lineOutput += "* * "
                }
                if arr[col] < lineCount {
                    lineOutput += "    "
                }
            }
            lineOutput += "\n"
        }
        
        return lineOutput
    }
}
